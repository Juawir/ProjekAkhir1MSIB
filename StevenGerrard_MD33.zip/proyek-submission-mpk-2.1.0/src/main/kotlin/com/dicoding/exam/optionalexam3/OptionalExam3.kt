package com.dicoding.exam.optionalexam3

fun manipulateString(str: String, int: Int): String {
    val regex = Regex("\\d+")
    val matchResult = regex.find(str)

    return if (matchResult != null) {
        val numberInString = matchResult.value.toInt()
        val multipliedValue = numberInString * int
        str.replace(matchResult.value, multipliedValue.toString())
    } else {
        str + int.toString()
    }
}
