package com.dicoding.exam.exam1

// TODO 1
fun isEvenNumber(number: Int) = number % 2 == 0

// TODO 2
fun moreThanFive(number: Int) = number > 5

// TODO 3
fun result(number: Int): Int {
    return number * (number + 10)
}
