package com.dicoding.exam.optionalexam4

fun getMiddleCharacters(string: String): String {
    val length = string.length
    return if (length % 2 == 0) {
        // Panjang genap, ambil 2 karakter tengah
        string.substring(length / 2 - 1, length / 2 + 1)
    } else {
        // Panjang ganjil, ambil 1 karakter tengah
        string.substring(length / 2, length / 2 + 1)
    }
}
